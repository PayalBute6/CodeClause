package Project1;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

// Product class representing a product in the store
class Product {
    private int id;
    private String name;
    private double price;
    private String imagePath;

    public Product(int id, String name, double price, String imagePath) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.imagePath = imagePath;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public double getPrice() { return price; }
    public String getImagePath() { return imagePath; }
}

// Shopping Cart class
class Cart {
    private List<Product> cartItems = new ArrayList<>();

    public void addProduct(Product product) {
        cartItems.add(product);
    }

    public void removeProduct(int productId) {
        cartItems.removeIf(product -> product.getId() == productId);
    }

    public List<Product> getCartItems() {
        return cartItems;
    }

    public double getTotalPrice() {
        return cartItems.stream().mapToDouble(Product::getPrice).sum();
    }
}

// Main Application with GUI
public class ECommerceApp {
    private JFrame frame;
    private Cart cart;
    private JLabel totalLabel;
    private List<Product> products;

    public ECommerceApp() {
        cart = new Cart();
        products = Arrays.asList(
            new Product(1, "Laptop", 69999.99, "src/images/laptop.png"),
            new Product(2, "Phone", 39999.49, "src/images/phone.png"),
            new Product(3, "Headphones", 5999.99, "src/images/headphones.png"),
            new Product(4, "Smartwatch", 14999.99, "src/images/smartwatch.png"),
            new Product(5, "Gaming Mouse", 2999.99, "src/images/mouse.png"),
            new Product(6, "Speakers", 5999.99, "src/images/speakers.png")
        );
        initializeUI();
    }

    private void initializeUI() {
        frame = new JFrame("E-Commerce App");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 500);
        frame.setLayout(new BorderLayout());
        
        JPanel productPanel = new JPanel(new GridLayout(0, 2, 10, 10));
        productPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        for (Product product : products) {
            JPanel itemPanel = new JPanel(new BorderLayout());
            JLabel imageLabel = new JLabel(new ImageIcon(new ImageIcon(product.getImagePath()).getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH)));
            JLabel nameLabel = new JLabel(product.getName() + " - ₹" + product.getPrice(), SwingConstants.CENTER);
            JButton addToCartBtn = new JButton("Add to Cart");
            JButton buyNowBtn = new JButton("Buy Now");
            
            addToCartBtn.addActionListener(e -> openAddToCartWindow(product));
            buyNowBtn.addActionListener(e -> openBuyNowWindow(product));
            
            JPanel buttonPanel = new JPanel();
            buttonPanel.add(addToCartBtn);
            buttonPanel.add(buyNowBtn);
            
            itemPanel.add(imageLabel, BorderLayout.NORTH);
            itemPanel.add(nameLabel, BorderLayout.CENTER);
            itemPanel.add(buttonPanel, BorderLayout.SOUTH);
            productPanel.add(itemPanel);
        }
        
        totalLabel = new JLabel("Total: ₹0.00", SwingConstants.CENTER);
        totalLabel.setFont(new Font("Arial", Font.BOLD, 16));
        
        JButton checkoutBtn = new JButton("Checkout");
        checkoutBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(frame, "Total: ₹" + cart.getTotalPrice() + "\nCheckout complete!");
            cart = new Cart();
            updateTotal();
        });
        
        frame.add(new JScrollPane(productPanel), BorderLayout.CENTER);
        frame.add(totalLabel, BorderLayout.NORTH);
        frame.add(checkoutBtn, BorderLayout.SOUTH);
        frame.setVisible(true);
    }

    private void openAddToCartWindow(Product product) {
        JFrame addToCartFrame = new JFrame("Product Added to Cart");
        addToCartFrame.setSize(300, 200);
        addToCartFrame.setLayout(new BorderLayout());
        
        JLabel messageLabel = new JLabel("Added " + product.getName() + " to cart for ₹" + product.getPrice(), SwingConstants.CENTER);
        JLabel imageLabel = new JLabel(new ImageIcon(new ImageIcon(product.getImagePath()).getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH)), SwingConstants.CENTER);
        
        JButton okButton = new JButton("OK");
        okButton.addActionListener(e -> {
            cart.addProduct(product);
            updateTotal();
            addToCartFrame.dispose();
        });
        
        addToCartFrame.add(messageLabel, BorderLayout.NORTH);
        addToCartFrame.add(imageLabel, BorderLayout.CENTER);
        addToCartFrame.add(okButton, BorderLayout.SOUTH);
        addToCartFrame.setVisible(true);
    }

    private void openBuyNowWindow(Product product) {
        JFrame buyNowFrame = new JFrame("Purchase Confirmation");
        buyNowFrame.setSize(300, 200);
        buyNowFrame.setLayout(new BorderLayout());
        
        JLabel messageLabel = new JLabel("Purchased: " + product.getName() + " for ₹" + product.getPrice(), SwingConstants.CENTER);
        JLabel imageLabel = new JLabel(new ImageIcon(new ImageIcon(product.getImagePath()).getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH)), SwingConstants.CENTER);
        
        JButton okButton = new JButton("OK");
        okButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(buyNowFrame, "Thank you for your purchase!");
            buyNowFrame.dispose();
        });
        
        buyNowFrame.add(messageLabel, BorderLayout.NORTH);
        buyNowFrame.add(imageLabel, BorderLayout.CENTER);
        buyNowFrame.add(okButton, BorderLayout.SOUTH);
        buyNowFrame.setVisible(true);
    }

    private void updateTotal() {
        totalLabel.setText("Total: ₹" + cart.getTotalPrice());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ECommerceApp::new);
    }
}